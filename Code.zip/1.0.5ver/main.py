#
import os
import pystray  # 最小化托盘
import io  # 提供了用于处理流（stream）的接口。io 模块支持多种类型的流，包括文件流、内存流、网络流等，并提供了统一的接口来操作这些流。
import base64
from PIL import Image
from PIL import ImageTk
from icon import icon_data  # 自定义任务栏图标
import threading
import pyautogui
import win32gui
import win32con
from threading import Thread  # 提供了用于处理流（stream）的接口。io 模块支持多种类型的流，包括文件流、内存流、网络流等，并提供了统一的接口来操作这些流。


#校园网无响应时应暂停脚本或尝试连接wifi！，电脑睡眠后暂停工作现象,需要重启线程，cycle——login函数需要检测脚本启动状态！
# 调用 tk.Tk() 时，它会初始化 Tkinter /运行环境，并创建一个主窗口。返回值是实例
# 这个主窗口是所有其他 GUI 组件（如按钮、标签、文本框等）的容器。

#

# 配置文件隐藏,debug显示时间,防休眠,load配置提示框优化，开机自启动脚本并运行 ，代码瘦身,版本详情，使用说明,启动ui,音效添加?


#global app #全局变量
def main():

    from gui import app
    from gui import root
    from pump_thread import register_wake_notify
    # 再设置窗口图标


    app.root.wm_iconphoto(True, app.tk_icon)
    try:
        os.remove(app.temp_icon)
    except:
        pass
    # 删除临时图标文件


    if app.gui_ver != "new":
        x_position = (app.screen_width - app.main_window_width) // 2
        y_position = (app.screen_height - app.main_window_height) // 2 - 100
        print(app.main_window_width,app.main_window_height)
        app.root.geometry(size=(app.main_window_width,app.main_window_height),position=(x_position,y_position)) #重新更改gui尺寸
        pass

    register_wake_notify()  # 休眠自唤醒,修改后的注册方法
    root.mainloop()
    print(app.log)

if __name__ == "__main__":
    main()




"""
最后修改：增加认证信息自定义

"""

#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