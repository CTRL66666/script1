import time
import tkinter as tk
import maliang
import maliang.animation as animation
import math
import func_gui

def test(self):
    #self.root.geometry(size=(1100, self.main_window_height))

    self.cv.place(x=(1100 - (self.main_window_width/ 2)), y=self.main_window_height / 2, anchor="center")
    self.cv2.place(width=int(1100 - self.main_window_width), height=self.main_window_height, x=0, anchor="nw")
    self.root.after(100,self.cv2.place(width=int(1100 - self.main_window_width), height=self.main_window_height, x=0, anchor="nw"))


class Animation:#即App的子类
    def __init__(self,app,cv,main_size,step=10,frame_delay=10):
        self.app=app
        self.root=app.root
        self.cv=cv
        self.step = step  # 每次增加的宽度
        self.frame_delay = frame_delay  # 帧间隔(ms)
        self.main_size=main_size
        self.current_width=main_size[0]
        self.current_height=main_size[1]

    def start_animation(self,target_width): # 目标宽度
        def update_width():
            if self.current_width < target_width:
                self.current_width += self.step
                 #画布追踪
                self.root.center()
                #self.root.geometry(position=(self.cv.winfo_x()-self.step,int(self.cv.winfo_y()+self.current_height/2)))
                self.root.geometry(size=(self.current_width, self.current_height))
                self.cv.place(x=(self.current_width - (self.app.main_window_width / 2)), y=self.current_height / 2,
                              anchor="center") #会积累5单位误差，最后矫正,mainsize改为真实cv大小？
                self.app.cv2.place(width=self.current_width - self.app.main_window_width, height=self.app.main_window_height,
                                   x=0, anchor="nw")

                self.anim_id=self.root.after(self.frame_delay, update_width)
            else:
                while target_width - self.app.root.winfo_width() < self.step:
                    #最终对齐补偿
                    #self.root.after_cancel(self.anim_id)  # 停止动画循环
                    #self.root.geometry(size=(target_width, self.current_height)) #此行补偿导致缩放！！

                    self.cv.place(x=(target_width - (self.app.main_window_width / 2)), y=self.current_height / 2,width=self.main_size[0],height=self.main_size[1],anchor="center")
                    self.app.cv2.place(width=int(target_width - self.app.main_window_width),height=self.app.main_window_height, x=0, y=0, anchor="nw")

                    #test(self.app)

                    print(
                        f"补偿后窗口宽度1.0: {self.app.root.winfo_width()}, cv1宽度: {self.app.cv.winfo_width()},cv1右侧位置: {self.app.cv.winfo_x() + self.app.cv.winfo_width()}")


                    print(
                        f"cv2设计宽度: {target_width - self.app.main_window_width},cv2设计x位置:{self.app.main_window_width - target_width}")
                    print(f"cv2实际宽度0.0: {self.app.cv2.winfo_width()},cv2右侧实际位置: {self.app.cv2.winfo_x() + self.app.cv2.winfo_width()}")
                    print(f"窗口宽度: {self.root.winfo_width()}, 画布右侧位置: {self.cv.winfo_x() + self.cv.winfo_width()}")

                    print("动画结束")
                    return True

        print("update()2doing")
        update_width()
        if True:
            #这一段是第一被执行的片段


            return True

def create(app,main_size,target_width=1000,step=10,frame_delay=1):
    try:
        if app.cv2 is not None and app.cv2.winfo_exists():
            app.cv2.destroy()
            pass
    except:pass
    print("开始创建cv2")
    app.cv2 = maliang.Canvas(bg="lightgreen", auto_update=False, keep_ratio="min",free_anchor=False, auto_zoom=False)
    maliang.Image(app.cv2, position=(target_width-main_size[0], 0), anchor="ne", size=(target_width-main_size[0], main_size[1]),
                  image=maliang.PhotoImage(file=func_gui.resource_path("school.jpg")))

    animation=Animation(app,app.cv,main_size,step,frame_delay)
    print("start_animation1...")
    #maliang.Image(cv,(100,50),image=maliang.PhotoImage(file="./image.ico"), anchor="center") #main_size[1]/2

    result=animation.start_animation(target_width)#mainsize更新?

    #cv.place(x=(target_width - (main_size[0] / 2)) + 5, y=main_size[1] / 2,anchor="center") #置顶？
    if result:#app.root.cget("width")和app.root.winfo_width()返回不同值
        print(
            f"窗口宽度1.0: {app.root.winfo_width()}, cv1宽度: {app.cv.winfo_width()},cv1右侧位置: {app.cv.winfo_x() + app.cv.winfo_width()}")
        #print(f"cv2实际宽度: {app.cv2.winfo_width()},cv2右侧实际位置: {app.cv2.winfo_x() + app.cv2.winfo_width()}")
        print(f"cv2设计宽度1.0: {target_width - app.main_window_width},cv2设计x位置:{app.main_window_width - target_width}")
        #app.cv2.place(width=target_width - app.main_window_width, height=500,x=app.main_window_width - target_width, anchor="nw")  # 配置cv2

        #app.cv2.config(width=target_width - app.main_window_width, height=500)


    return animation


class AhphaAnimation(animation.Animation):
    """My customized animation class"""

    def __init__(self, ms: int, window: maliang.Tk, *args, **kwargs) -> None:
        """Let the window gradually change from transparent to clear"""
        controller = animation.generate(math.sin, math.pi/3, math.pi*2/3, map_y=False)
        super().__init__(ms, window.alpha, controller=controller, *args, **kwargs)


'''

        print(
            f"窗口宽度1.1: {app.root.cget("width")}, cv1宽度: {app.cv.cget("width")},cv1右侧位置: {app.cv.winfo_x() + int(app.cv.cget("width"))}")
'''


