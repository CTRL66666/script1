import requests

import re
import threading
import webbrowser
import tkinter as tk
from tkinter import scrolledtext,messagebox

#from gui import app

# 配置参数

def get_version(self,content=".后缀",update=1): #放入gui中，lambad self.version
    need_update = False
    owner = "CTRL66666" # 用户名
    repo = "script1" # 仓库名称
    url = f"https://api.github.com/repos/{owner}/{repo}/contents/"

    headers = {
        "Accept": "application/vnd.github.v3+json"  # "Authorization": f"Bearer {token}",
    }

    response = requests.get(url, headers=headers,timeout=5)#,verify=False
    if response.status_code == 200:
        files = response.json()
        download_url = {}
        for item in files:
            print(f"文件名: {item['name']} | 类型: {item['type']} | 路径: {item['path']},| 下载链接: {item['download_url']}")
            download_url[str(item['name'])]=item['download_url']
            if re.search(r"\.version(.*)",item['name']):
                version=re.search(r"\.version(.*)",item['name']).group(1)
                print("查询最新版本号是:",version)

                print("当前版本号是:", self.version)
                if int(self.version.replace(".","")) < int(version.replace(".","")):
                    print("发现新版本!")
                    need_update = True
                else:
                    print("当前版本是最新版本")
        if update: #update变量表明是否为检查更新选项
            if need_update :
                result = messagebox.askquestion("发现新版本！", f"是否更新至最新版本:V{version}\n跳转至浏览器获取镜像github下载链接")
                # 根据用户的选择执行不同的操作
                if result == 'yes':
                    print("默认进入镜像通道中")
                    get_originalFile_content(download_url, ".exe", channel="mirror")
                else:
                    pass

            else:messagebox.showinfo("已是最新版本","当前您的软件已是最新版本，无需更新！")

        if content==".md":#README软件说明选项
            messagebox.showinfo("加载中","正在获取文本,请等待大约5~15秒...")
            update_thread = threading.Thread(target=lambda:get_originalFile_content(download_url, content, channel="mirror"), daemon=True)
            update_thread.start()
        return download_url
    else:
        print(f"请求失败，状态码: {response.status_code}")
        messagebox.showinfo("请求失败", f"状态码: {response.status_code}")


def get_originalFile_content(file_info,content,channel="mirror"):

    try:
        for file in file_info:
            if file.endswith(content):
                target=file

        mirror_url = "https://raw.kkgithub.com" + str(file_info[target]).split(".com", 1)[1]


        if channel=="original":
            if content != ".exe":
                print("向原网站发送请求")
                response = requests.get(file_info[target],verify=False)
            else:
                print("打开原网站:", file_info[target])
                webbrowser.open(file_info[target])
                return True
        elif channel=="mirror":
            if content!=".exe":
                print("向镜像网站发送请求:",mirror_url)
                response = requests.get(mirror_url)
            else:
                print("打开镜像网站:", mirror_url)
                webbrowser.open(mirror_url)
                messagebox.showinfo("提示", "若下载被拦截,可于浏览器【下载】中保留恢复\n或更换浏览器下载")
                return True

        if content != ".exe":#创建可视信息窗口栏
            if response.status_code == 200: #用于获取文本内容
                print("获取文本内容中")
                #print("response.text:",response.text)
                show_window_info("软件说明",response.text)
                return response.text  # 对于文本文件
        else:
            print(f"获取文件内容失败，状态码: {response.status_code}")
            return None
    except Exception as e:
        print(f"获取文件内容时发生错误: {e}")
        messagebox.showinfo("失败", "获取文本失败,请重试或检查网络环境")
        return None

'''
def get_mirrorFile_content(file_info):
    try:
        for file in file_info:
            if file.endswith(".exe"):
                target=file

        origial_url=file_info[target]
        mirror_url="https://raw.kkgithub.com"+str(origial_url).split(".com",1)[1]
        print("打开镜像网站:",mirror_url)
        webbrowser.open(mirror_url)
    except:pass
'''
def show_window_info(title="软件说明",content=""):
    info_window = tk.Toplevel()
    info_window.title(title)
    info_window.geometry("800x600")
    info_window.resizable(True, True)

    # 创建滚动文本框
    text_area = scrolledtext.ScrolledText(info_window, wrap=tk.WORD)
    text_area.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

    # 插入说明文本
    text_area.insert(tk.END, content)
    text_area.config(state=tk.DISABLED)

    # 添加关闭按钮
    close_button = tk.Button(info_window, text="关闭", command=info_window.destroy)
    close_button.pack(pady=10)


#down_url=get_version(url,headers)


#截取.com/后面所有地址作为变量，首先采用GitHub镜像raw.kkgithub.com访问下载链接，若无效，提示用户手动进入GitHub官网下载
#https://raw.kkgithub.com/CTRL66666/script1/main/ver1.45