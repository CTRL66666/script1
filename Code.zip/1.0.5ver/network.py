import subprocess
import requests
import random
import requests.exceptions
def get_current_ip():  # 返回ip值
    cmd = "ipconfig"
    searched = 0
    result = subprocess.run(cmd, capture_output=True, text=True)
    for line in result.stdout.split('\n'):
        if "无线局域网适配器 WLAN" in line in line and not searched:  # 锁定后就跳过
            searched = 1
        if searched:
            if "IPv4 地址" in line or "IPv4 Address" in line:
                return line.split(":")[1].strip()  # 整个表达式的结果是一个字符串，即原字符串line中冒号后面的部分，且去除了首尾的空格和换行符。
    if not searched:
        return None

def connect_to_wifi(ssid):  # 连接无密码网络
    # 断开现有 WiFi 连接
    wlan=get_connected_wifi()

    if wlan != ssid:
        print("目前非校园网网络,尝试断开现有 WiFi...")
        disconnect_result = subprocess.call(["netsh", "wlan", "disconnect"])
        if disconnect_result != 0:
            print("断开现有 WiFi 连接失败")
            pass
        else:print("断开现有 WiFi(非校园网) 连接成功")
 # 连接到指定 WiFi
        connect_result = subprocess.call(["netsh", "wlan", "connect", "name=" + ssid])
        if connect_result != 0:
            print("切换到指定 WiFi 失败")
            return False
        else:print("切换到 WiFi 成功")
    else:print("目前网络为校园网,跳过connect_to_wifi()")

    return True

def get_connected_wifi():
    cmd = 'netsh wlan show interfaces'
    try:
        result = subprocess.check_output(cmd, shell=True,creationflags=subprocess.CREATE_NO_WINDOW).decode('utf-8')
    except:
        result = subprocess.check_output(cmd, shell=True,creationflags=subprocess.CREATE_NO_WINDOW).decode('gbk')
    for line in result.split('\n'):
        if 'SSID' in line and 'BSSID' not in line:
            return line.split(':')[-1].strip()
    return False #此行不能改，否则造成循环


def network_check(second=3):  # 默认3秒
    net_list = ["https://daohang.qq.com/", "https://www.sogou.com", "https://cn.bing.com", "https://www.msn.cn"]    #ping检测池
    net = net_list[random.randint(0, 3)]
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
        "Accept-Language": "zh-CN,zh;q=0.8,en-US;q=0.5,en;q=0.3",
        "Accept-Encoding": "gzip, deflate, br",
        "Connection": "keep-alive"
    }
    try:
        # 访问搜索引擎，验证网络
        print("network_check():访问网址并测试网络状态中：", net)
        resp = requests.get(net, timeout=second,headers=headers)  # 在列表中随机访问地址

        if resp.status_code == 200:  # 根据返回页关键词调整 ,删除了"refresh" in resp.text or
            return True
        else:
            print("network_check():状态码不符,返回False")
            return False

    except (Exception,ConnectionError,requests.exceptions.RequestException) as e:  #Connected aborted  Connection aborted.', ConnectionResetError(10054, '远程主机强迫关闭了一个现有的连接。', None, 10054, None))
        if "ConnectionResetError" in str(e):
            print("network_check():将跳过ConnectionResetError并返回True", net)
            return True
        else:
            print("network_check():该网址连接错误或超时,函数返回False", net)
            print("错误收集:", e)
            return False


    #JQbjZMdv364tV5dH-jiuQkCS