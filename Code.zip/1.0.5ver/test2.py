import maliang
import maliang.theme as theme
import tkinter as tk
from tkinter import ttk
from tkinter import scrolledtext,messagebox
import time
import random
import json
import requests
import os
import io  # 提供了用于处理流（stream）的接口。io 模块支持多种类型的流，包括文件流、内存流、网络流等，并提供了统一的接口来操作这些流。
import base64
import PIL.Image
from PIL import Image
from PIL import ImageTk
from icon import icon_data  # 自定义任务栏图标
from threading import Thread
  # 提供了用于处理流（stream）的接口。io 模块支持多种类型的流，包括文件流、内存流、网络流等，并提供了统一的接口来操作这些流。
#以下导入自定义模块
import window
import win32api##
import network
import auto_start
import func_gui
import tray_thread
import update
import test2
class App:
    def __init__(self, root):
        self.version = "1.0.2"  #版本号
        self.root = root

        # 状态栏区域

        self.root.title(f"防断连程序V{self.version}")
        try:
            self.temp_icon = "temp_icon.ico"
            with open(self.temp_icon, "wb") as f:
                f.write(base64.b64decode(icon_data))
                self.root.wm_iconbitmap(self.temp_icon)
        except:
            pass

        # 设置窗口图标

        self.icon_image = Image.open(
            io.BytesIO(base64.b64decode(icon_data)))  # 将Base64编码的图像数据解码，并将其转换为一个图像对象，然后存储在实例变量self.icon_image中，以便后续使用。
        self.tk_icon = ImageTk.PhotoImage(self.icon_image)
        # 创建临时图标文件

        self.root.wm_iconphoto(True, self.tk_icon)

        self.screen_width = self.root.winfo_screenwidth()
        self.screen_height = self.root.winfo_screenheight()
        self.main_window_width = int(self.screen_width * (420 / 1920))  # 1080p环境
        self.main_window_height = int(self.screen_height * (500 / 1080))




        # 后台托盘线程初始化
        self.tray_icon = None
        self.tray_thread = None
        #脚本线程初始化
        self.script_thread=None



        self.config = dict()  # 创建字典
        self.config['static_ip'] = network.get_current_ip()
        self.config['channel'] = "@telecom"  # 运营商默认电信
        self.wlan_switch = True  # 默认选择切换wifi
        self.key_show_locked = 0  # 锁定密码展示
        self.login_count = 0  # 登录次数
        self.loop_time = 20  # 默认循环时间
        self.timer = 0  # 定时器
        self.start_sign = 0  # 启动标志，默认关闭
        self.pystray_sign=0 #默认关闭托盘常驻
        self.max_login = 10  # 最大登录次数默认 10
        self.open_to_use = False  # 程序打开即用
        self.has_worked = 0  # 自动运行工作状态标记
        self.wlan_finished=None
        self.login_result=None
        self.script_thread = None
        self.log = []  # 初始化列表访问日志
        self.mac_user = os.environ.get('USERNAME')
        self.path = f"C:\\Users\\" + self.mac_user + "\\ConnectConfig.json"  ##
        self.create_widgets()  # 创建gui图形页面
        self.is_loaded = self.load_settings()  # 加载配置，并保存返回值 ##
        func_gui.status_refresh(self)
        self.top_levels = []  # 子窗口列表
        self.debug_window = None  # 调试窗口
        self.original_print = print  # 保存原始的 print 函数
        self.wlan = network.get_connected_wifi()

        self.hwnd = None  # 新增窗口句柄


    def create_widgets(self):#!
        # self.root.configure(bg="#FFFFFD") #背景颜色调整

        cv = maliang.Canvas(root,auto_zoom=True, keep_ratio="min", free_anchor=False,bg="#FFFDFE",auto_update=False)
        self.cv=cv
        cv.place(width=self.main_window_width, height=self.main_window_height, x=(main_size[0]-(self.main_window_width/2)), y=self.main_window_height/2, anchor="center")

        maliang.Text(cv, (210, 50), text="网 络 连 接 工 具", fontsize=45, anchor="center")

        maliang.Text(cv, (10, 210), text="一卡通号", anchor="nw")
        self.username=maliang.InputBox(cv, (80, 200), (280, 50), placeholder="点击输入一卡通号")
        maliang.Text(cv, (10, 290), text="密   码", anchor="nw")
        self.password=maliang.InputBox(cv, (80, 280), (280, 50), show="●", placeholder="点击输入密码")

        #maliang.Button(cv, (450, 640), (180, 50), text="注 册")

        style = ttk.Style()

        # 创建一个新的样式 'Custom.TButton'
        style.configure('Custom.TButton',
                        foreground='white',  # 文本颜色
                        background='blue',  # 背景颜色
                        bordercolor='black',  # 边框颜色
                        font=('Arial', 12, 'bold'),  # 字体
                        padding=(10, 5))  # 内边距

        # 启动按钮
        self.start_btn = maliang.IconButton(cv, text="           启动脚本",position=(210, 430),size=(300, 50),anchor="center",justify="center",image=maliang.PhotoImage(file="./image.ico").resize(30,30),
                                        command=self.start_script)  # 返回值是一个 Button 对象，代表创建的按钮。以用于进一步的操作，比如修改按钮的属性或获取按钮的状态。

        self.channel_btn=maliang.SegmentedButton(cv, (365, 190),sizes=((40,40),(40,40)),text=("电信", "移动"),default=bool(self.pystray_sign),layout="vertical",command=lambda event:(self.telecom()))
        self.channel_btn.get()


        #maliang.Switch(cv, (300, 350),length=30,default=bool(self.pystray_sign),command=lambda event:(self.telecom()))


        """
        # 账号框
        tk.Label(self.root, text="一卡通号:").grid(row=0, column=0, padx=5, pady=5)
        self.username = tk.Entry(self.root)  # 创建文本输入框,依附于root窗口
        self.username.grid(row=0, column=1, padx=5, pady=5)  # 对输入框设置位置

        # 密码框
        tk.Label(self.root, text="密  码:").grid(row=1, column=0, padx=5, pady=5)
        self.password = tk.Entry(self.root, show="*")  # 创建文本输入框,依附于root窗口
        self.password.grid(row=1, column=1, padx=5, pady=5)  # 对输入框设置位置

        # 保存按钮
        save_btn = tk.Button(self.root, text="保存配置",
                             command=self.save_settings)  # 返回值是一个 Button 对象，代表创建的按钮。以用于进一步的操作，比如修改按钮的属性或获取按钮的状态。
        save_btn.grid(row=2, column=0, padx=2, pady=2)

        # 启动按钮
        self.start_btn = tk.Button(self.root, text="启动脚本",
                                   command=self.start_script)  # 返回值是一个 Button 对象，代表创建的按钮。以用于进一步的操作，比如修改按钮的属性或获取按钮的状态。
        self.start_btn.grid(row=2, column=1, padx=2, pady=5)  # 尝试self属性

        # 调试按钮
        debug_btn = tk.Button(self.root, text="调试模式", command=lambda:window.toggle_debug_window(self))
        debug_btn.grid(row=4, column=0, padx=3, pady=3)

        # 运营商按钮
        self.telecom_btn = tk.Button(self.root, text="电信", command=self.telecom, relief=tk.RAISED)
        self.telecom_btn.grid(row=0, column=2, padx=5, pady=5)

        self.cmcc_btn = tk.Button(self.root, text="移动", command=self.cmcc, relief=tk.RAISED)
        self.cmcc_btn.grid(row=1, column=2, padx=5, pady=5)

        # 设置按钮
        setting_btn = tk.Button(self.root, text="设置", command=self.more_setting)
        setting_btn.grid(row=2, column=2, padx=2, pady=5)




        """

    def save_settings(self):
        self.config['version'] = self.version
        self.config['username'] = self.username.get()
        self.config['password'] = self.password.get()  # 库方法获取文本输入框的字符串
        with open(self.path, "w") as config_file:
            json.dump(self.config, config_file)

        messagebox.showinfo("成功", f"配置已保存至路径:,{self.path}")

        print("Save Done")
        pass

    def load_settings(self):
        try:
            with open(self.path, "r") as config_file:
                self.config = json.load(config_file)
                print("try config load")
                self.username.insert(0, self.config.get("username", ""))
                self.password.insert(0, self.config.get("password", ""))
                if self.config["channel"] == "@telecom":
                    self.telecom()
                else:
                    self.cmcc()  # 载入运营商配置
                self.wlan_switch = self.config.get("wlan_switch", True)  # wifi自动寻找切换功能，默认真
                self.max_login = self.config.get("max_login", 10)  # 默认10
                self.loop_time = self.config.get("loop_time", 20)  # 默认20
                self.pystray_sign = self.config.get("pystray_sign", 0)  # 后台运行标志，默认0
                if self.pystray_sign: self.root.protocol('WM_DELETE_WINDOW', lambda:tray_thread.minimize_to_tray(self))  # 检测并是否启用后台#!
                self.key_show_locked = self.config.get("key_show_locked", 0)  # 密码锁定标签，默认0
                self.open_to_use = self.config.get("open_to_use", False)  # 打开程序自动启动脚本选项

                if self.open_to_use and not self.has_worked:
                    print("启用自运行")
                    self.root.after(3000, self.start_script)  # self.start_script

                self.root.wm_iconphoto(True, self.tk_icon)

                if self.config["version"] != self.version:
                    messagebox.showinfo("提示","欢迎使用新的程序版本!\n已自动为您更新配置")
                    if auto_start.check_auto_start(): #自启动更新！
                        auto_start.disable_auto_start()
                        auto_start.create_shortcut()
                    self.save_settings()

            return True
        except:
            print("失败", "配置文件应用错误")
            return False

    def start_script(self):
        import main
        root.geometry(size=(1500,500))
        print("Try start_script()")


        self.wlan = network.get_connected_wifi()
        error_legal = 0
        self.start_sign = 1

        try:
            self.config['username'] = self.username.get()
            self.config['password'] = self.password.get()  # 库方法获取文本输入框的字符串
            self.config["UniData_to_check"] = self.config['username'] + self.config['password']
            if self.open_to_use and self.pystray_sign and not self.has_worked:  # 检测打开了后台运行选项就启用下列代码
                func_gui.status_refresh(self)
                self.root.after(500, lambda:tray_thread.minimize_to_tray(self))  # 可能每次after操作都会执行按钮start的命令,
                self.root.after(100, lambda:window.show_disappear_message("防断连后台运行中",duration=6000))  #####
                self.has_worked = 1

            # 检测有无不合法字符
            for value in self.config["UniData_to_check"]:
                if not value:
                    error_legal = 1  # 检测是否输入值了,值为空就错误
                    for char in value:
                        print(char)
                        if not (1 <= ord(char) <= 127):  # ASCII码检测 原33...126
                            error_legal = 1
            if error_legal:
                messagebox.showerror("错误", f"输入了不合法字符或有输入为空 ")
                return False
            if not error_legal:  # 保存配置

                self.params = {
                    "callback": "dr1003",
                    "login_method": "1",
                    "user_account": self.config['username'] + self.config['channel'],  # 替换你的账号V   移动@cmcc 电信@telecom
                    "user_password": self.config['password'],  # 替换你的密码
                    "wlan_user_ip": network.get_current_ip(),
                    "wlan_user_ipv6": "",
                    "wlan_user_mac": "",  #
                    "wlan_ac_ip": "10.17.4.1",
                    "wlan_ac_name": "",
                    "jsVersion": "4.1.3",
                    "terminal_type": "1",
                    "lang": "zh-cn",  # 注意有两个lang参数，建议保留最后一个
                    "v": str(random.randint(1000, 9999)),  # 这个参数现在不知用处，可以用随机函数让此数在四位数随机
                    "lang": "zh"  # 实际生效的lang参数
                }
                self.wlan_finished = 0
                window.show_disappear_message("启动中", duration=3000)

                func_gui.status_refresh(self)
                if self.wlan_switch and self.wlan != "JXUST-WLAN":  # 条件：打开自动切换开关且WiFi不符校园网
                    print("正在执行切换Wifi命令")
                    if network.connect_to_wifi("JXUST-WLAN"):  # 自动退出原来网络，切换wifi
                        self.status_label.config(text=f"切换wifi步骤成功!")
                        # 计时不阻塞，采用多线程#
#
                        # while self.result==False: root.mainloop()  #为0时####
                        self.wlan_finished = 1
                        # self.wlan=get_connected_wifi()
                        print("切换wifi步骤成功")

                    else: #切换Wifi失败，则提示
                        self.wlan_finished = 0
                        print("切换wifi步骤失败")
                        messagebox.showerror("登陆失败Code:2", "未搜寻到校园网,请检查是否打开WLAN")
                elif self.wlan_switch == False or self.wlan == "JXUST-WLAN":
                    self.wlan_finished = 1
                    pass
                func_gui.status_refresh(self)
                print("wlan_finished:", self.wlan_finished)
                if self.wlan_finished :
                    self.login_result=self.login()  ##### Wlan检查(无论Wifi切换开关打开与否)结束后，执行登录操作，并检测login返回值
                    if self.login_result:
                        window.show_disappear_message("成功连接!", duration=3000)
                        root.after(800,lambda:func_gui.status_refresh(self))
                        if not self.open_to_use:  # 如果没启动自动运行，则触发提示框
                            messagebox.showinfo(title=self.config['channel'] + "成功登录", message="Wifi已在线")

                        self.config["key_show_locked"] = 1

                        # 进入自动执行函数，守护线程运行
                        if self.login_count < self.max_login and self.start_sign:
                            self.script_thread = Thread(target=self.cycle_login, daemon=True)  # 守护线程
                            self.script_thread.start()
                            # gui刷新,停止按钮
                            self.end_btn = tk.Button(self.root, text="停止脚本", command=self.end_script)
                            self.end_btn.grid(row=2, column=1, padx=2, pady=5)  # 尝试self属性

                        if self.login_count >= self.max_login:
                            messagebox.showinfo(title=self.config['channel'] + "登录停止", message="已达最大登录次数上限")
                            self.start_sign = 0  # 启动标志置零

                        return True
                    elif self.login_result == False or not self.wlan_finished:
                        messagebox.showerror("登陆失败Code:3",
                                             "请检查账号及密码或运营商配置\nTip:确认是否连接校园网或勾选Wifi切换开关")
                        func_gui.status_refresh(self)
                        self.start_sign = 0  # 启动标志置零
                    print("执行了一次登录指令")

        except Exception as e:
            print(e)
            messagebox.showerror("错误Code:1", f"获取数据失败: {str(e)}")

    def end_script(self):
        self.start_sign = 0
        self.timer = 0
        func_gui.status_refresh(self)

        self.login_count = 0

        self.start_btn = tk.Button(self.root, text="启动脚本", command=self.start_script)
        self.start_btn.grid(row=2, column=1, padx=2, pady=5)
        print("End_Script Done")

    def more_setting(self):

        try:
            self.setting_root.destroy()
        except:pass
        self.setting_root = tk.Toplevel(self.root)  # root的子窗口
        self.setting_root.title("设置")
        # 设置第4行的最小高度为50像素
        self.setting_root.rowconfigure(4, minsize=1)
        self.setting_root.rowconfigure(5, minsize=3)

        self.show_password_btn = tk.Button(self.setting_root, text="密码显示", command=self.show_password)
        self.show_password_btn.grid(row=1, column=0, padx=5, pady=5)

        self.pystray_btn = tk.Button(self.setting_root, text="后台常驻", command=lambda:tray_thread.pystray_switch(self))  # 666
        self.pystray_btn.grid(row=1, column=1, padx=5, pady=5)

        log_btn = tk.Button(self.setting_root, text="查看日志", command=self.visit_log)
        log_btn.grid(row=1, column=2, padx=5, pady=5)

        log_btn = tk.Button(self.setting_root, text="关于软件", command=self.about_more)
        log_btn.grid(row=4, column=2, padx=5, pady=5)


        loop_time_btn = tk.Button(self.setting_root, text="更改查询周期", command=self.loop_time_set)
        loop_time_btn.grid(row=2, column=1, padx=1, pady=1)
        self.loop_time_label = tk.Label(self.setting_root, text=str(self.loop_time) + " 秒 ", width=5,
                                        font=("Arial", 14, "bold"))
        self.loop_time_label.grid(row=2, column=2, padx=1, pady=1)
        self.loop_lag_entry = tk.Entry(self.setting_root, width=6)
        self.loop_lag_entry.grid(row=2, column=0, padx=1, pady=1)

        login_max_btn = tk.Button(self.setting_root, text="更改连接次数", command=self.login_max_set)
        login_max_btn.grid(row=3, column=1, padx=1, pady=1)
        self.login_max_label = tk.Label(self.setting_root, text=str(self.max_login) + " 次 ", width=5,
                                        font=("Arial", 14, "bold"))
        self.login_max_label.grid(row=3, column=2, padx=1, pady=1)
        self.login_max_entry = tk.Entry(self.setting_root, width=6)
        self.login_max_entry.grid(row=3, column=0, padx=1, pady=1)
        # 开机自启动选项
        self.auto_start_var = tk.BooleanVar(
            value=auto_start.check_auto_start())  # 创建一个 BooleanVar 对象，并将其初始值设置为 self.check_auto_start() 方法的返回值。这样，如果 self.check_auto_start() 返回 True，那么 BooleanVar 对象的值就是 True，表示复选框默认是选中的；如果返回 False，则表示复选框默认是未选中的。
        auto_start_check = tk.Checkbutton(  # 确认键
            self.setting_root,
            text="开机自启动\n[用户级]",
            variable=self.auto_start_var,  # 将复选框的状态与前面创建的 BooleanVar 变量绑定。这意味着当用户点击复选框时，auto_start_var 的值会自动更新为相应的布尔值。
            command=lambda:auto_start.toggle_auto_start(self) #切换自启动状态函数
        )
        auto_start_check.grid(row=4, column=0, padx=1, pady=5)

        # 自动切换wifi选项
        self.wlan_switch_var = tk.BooleanVar(
            value=self.wlan_switch)  # 创建一个 BooleanVar 对象，并将其初始值设置为 self.wlan_switch 方法的返回值。这样，如果 self.wlan_switch 返回 True，那么 BooleanVar 对象的值就是 True，表示复选框默认是选中的；如果返回 False，则表示复选框默认是未选中的。
        wlan_switch_check = tk.Checkbutton(  # 确认键
            self.setting_root,
            text="自动切换wifi",
            variable=self.wlan_switch_var,
            # 将复选框的状态与前面创建的 BooleanVar 变量绑定。这意味着当用户点击复选框时，wlan_switch_var 的值会自动更新为相应的布尔值。
            command=self.wlan_auto_switch
        )
        wlan_switch_check.grid(row=4, column=1, padx=5, pady=5)
        # 启动自动运行脚本选项
        self.open_to_use_var = tk.BooleanVar(
            value=self.open_to_use)  # 创建一个 BooleanVar 对象，并将其初始值设置为 self.wlan_switch 方法的返回值。这样，如果 self.wlan_switch 返回 True，那么 BooleanVar 对象的值就是 True，表示复选框默认是选中的；如果返回 False，则表示复选框默认是未选中的。
        open_to_use_var = tk.Checkbutton(  # 确认键
            self.setting_root,
            text="默认启动时运行工具",
            variable=self.open_to_use_var,
            # 将复选框的状态与前面创建的 BooleanVar 变量绑定。这意味着当用户点击复选框时，wlan_switch_var 的值会自动更新为相应的布尔值。
            command=self.open_to_use_switch
        )
        open_to_use_var.grid(row=5, column=1, padx=5, pady=5)

        self.setting_window_width = int(self.screen_width * (372 / 1920))  # 1080p环境
        self.setting_window_height = int(self.screen_height * (220 / 1080))

        x_position = (self.screen_width - self.setting_window_width) // 2  # 居中
        y_position = (self.screen_height - self.setting_window_height) // 2 - 100  # 稍微偏上
        self.setting_root.geometry(
            f"{self.setting_window_width}x{self.setting_window_height}+{x_position}+{y_position}")

    def telecom(self):
        self.config['channel'] = '@telecom'
        try:
            self.cmcc_btn.config(relief=tk.RAISED, bg="lightgray")
            window.toggle_relief(self.telecom_btn)
        except:pass
        print('telecom Done')
        return True

    def cmcc(self):
        self.config['channel'] = '@cmcc'
        try:
            self.telecom_btn.config(relief=tk.RAISED, bg="lightgray")
            window.toggle_relief(self.cmcc_btn)
        except:pass
        print('cmcc Done')
        return True

    def visit_log(self):
        print('log Done')
        show_log = "日志\n"
        for element in self.log:
            show_log = show_log + element + "\n"
        messagebox.showinfo(title="日志", message=show_log)
        return True

    def show_password(self):
        if self.password.cget("show") == "*" and self.key_show_locked == 0:
            self.password.config(show="")
            self.show_password_btn.config(text="密码显示")
        elif self.password.cget("show") == "" and self.key_show_locked == 0:
            self.password.config(show="*")
            self.show_password_btn.config(text="密码隐藏")
        else:
            messagebox.showerror("拒绝", f"密码信息正确,无需查看正确密码")

        pass

    def about_more(self):
        try:
            self.about_root.destroy()
        except:pass
        self.about_root = tk.Toplevel(self.root)  # root的子窗口
        self.about_root.title("关于软件")

        self.show_README_btn = tk.Button(self.about_root, text="软件说明", command=lambda:update.get_version(self,content=".md",update=0))
        self.show_README_btn.grid(row=1, column=1, padx=35, pady=5)

        self.find_update_btn = tk.Button(self.about_root, text="检查更新", command=lambda:update.get_version(self,update=1))
        self.find_update_btn.grid(row=2, column=1, padx=35, pady=5)

        self.pass_btn = tk.Button(self.about_root, text="感谢支持", command=lambda:messagebox.showinfo("感谢支持","若有疑问请向作者反馈"))
        self.pass_btn.grid(row=3, column=1, padx=35, pady=5)




        self.about_root_window_width = int(self.screen_width * (15 / 1920))  # 1080p环境
        self.about_root_window_height = int(self.screen_height * (180 / 1080))

        x_position = (self.screen_width - self.about_root_window_width) // 2  # 居中
        y_position = (self.screen_height - self.about_root_window_height) // 2 - 100  # 稍微偏上
        self.about_root.geometry(
            f"{self.about_root_window_width}x{self.about_root_window_height}+{x_position}+{y_position}")



    def wlan_auto_switch(self):
        if self.wlan_switch:
            self.wlan_switch = False
        else:
            self.wlan_switch = True

        self.config["wlan_switch"] = self.wlan_switch
        if self.wlan_switch:
            #messagebox.showinfo(title="提示", message="已启用Wifi自动切换")
            result=messagebox.askquestion(title="提示",message="已启用Wifi自动切换,是否保存配置")

        else:
            result=messagebox.askquestion(title="提示",message="已关闭Wifi自动切换,是否保存配置")

        if result == 'yes':
            self.save_settings()
        else:
            pass

        print("wlan_auto_switch Done")

    def open_to_use_switch(self):
        if self.open_to_use:
            self.open_to_use = False
        else:
            self.open_to_use = True
        self.config["open_to_use"] = self.open_to_use
        if self.open_to_use:
            result=messagebox.askquestion(title="提示", message="已启用默认自动运行工具\n是否保存配置")

        else:
            result=messagebox.askquestion(title="提示", message="已禁用默认自动运行工具\n是否保存配置")

        if result == 'yes':
            self.save_settings()
        print("open_to_use_switch() Done")
        pass




    def loop_time_set(self):
        try:
            self.loop_time = round(float(self.loop_lag_entry.get()),1)
            if self.loop_time >= 0.5: #尝试0.5也可以
                self.config['loop_time'] = self.loop_time
                self.loop_time_label.config(text=str(self.loop_time) + " 秒 ")
            else:
                messagebox.showerror("失败", f"请输入正整值或0.5的倍数!")
        except ValueError:
            messagebox.showerror("失败", f"请输入有效数字!")

    def login_max_set(self):
        try:
            self.max_login = int(self.login_max_entry.get())
            if self.max_login >= 1:
                self.config['max_login'] = self.max_login
                self.login_max_label.config(text=str(self.max_login) + " 次 ")
            else:
                messagebox.showerror("失败", f"请输入正整值!")
        except ValueError:
            messagebox.showerror("失败", f"请输入有效数字!")

    def login(self):
        response=None #变量初始化
        print("进入到Login操作")
        print("Login(): 正在尝试第一次发送登录请求,首先进行第一次网络检测")
        if network.network_check(2): #如果network_check结果是True，则执行else
            print("检测网络未断开，未执行校园网登录请求")
            return True  # 返回真值
        else:  ####### 1.43版修改:复核一次无网络时再执行登录操作,双重保障机制 #1.44:wlan审核
            #if self.wlan=="JXUST-WLAN": #1.44:wlan审核
            print("Network_check(2)超时,尝试发送第一次登录请求")
            self.login_count += 1  # 登录次数加一
            try:
                response = requests.get(
                    "http://10.17.8.18:801/eportal/portal/login",
                    params=self.params,
                    timeout=2
                )
            except:# 尝试两次
                #if response==None:
                    print("Login():第一次登录请求无响应，正在尝试进行第二次网络检测,并发送第二次登录请求")
                    if network.network_check(2):
                        print("Login():第二次检验网络正常，返回True值")
                        return True
                    else:
                        try:
                            self.wlan=network.get_connected_wifi()
                            if self.wlan_switch == 1 and self.wlan != "JXUST-WLAN":
                                connet_result=network.connect_to_wifi("JXUST-WLAN")  # 如果勾选自动切换网络选项，就尝试连接一次校园网Wifi
                                time.sleep(2.5) #睡眠一会，等待网络连接后稳定，再进行校园网登录
                            response = requests.get(
                                "http://10.17.8.18:801/eportal/portal/login",
                                params=self.params,
                                timeout=3
                            )

                        except:
                            print("登陆失败,校园网无响应")
                            result=messagebox.askquestion("登陆失败", "校园网无响应\n是否继续进行")
                            if result=="yes":
                                pass
                            else:
                                self.start_sign = 0  # 停止登录脚本
                                func_gui.status_refresh(self)#更新状态栏
                                return False
            try: #避免'NoneType' object has no attribute 'text'?
                if "成功" in response.text.lower():
                    print("校园网成功登录!")
                    self.log.append("Successful:" + time.strftime("%Y-%m-%d %H:%M:%S"))
                    return 1
                elif "在线" in response.text.lower():
                    print("校园网已经在线!")
                    self.log.append("Online:" + time.strftime("%Y-%m-%d %H:%M:%S"))
                    return 2
                elif "AC认证失败" in response.text.lower():
                    self.log.append("AC False:" + time.strftime("%Y-%m-%d %H:%M:%S"))
                    print("AC认证失败,将在下次循环重试")
                    return 3
                else:#还要屏蔽AC认证失败
                    print(f"登录失败，响应内容：{response.text[18:200]}...")
                    self.log.append("False:" + time.strftime("%Y-%m-%d %H:%M:%S"))
                    return False
            except:pass


    def cycle_login(self):
        while self.login_count < self.max_login and self.start_sign:
            print('cycle_login 1 Done')
            self.timer = 0
            while self.timer < self.loop_time and self.start_sign:
                time.sleep(0.5) #新修改：0.5为最小单位
                self.timer += 0.5

            if self.timer >= self.loop_time and self.start_sign:
                print('cycle_login 2 Done')

                if self.login() == 1:  # 进行登录操作，并确认值：：1是成功登录,2是已经在线，False是登录失败
                    print('cycle_login 3 Done')  # 最终连接结果

                func_gui.status_refresh(self)


                ##self.cycle_login()  # 递归易导致栈溢出
        else:
            if self.login_count >= self.max_login:
                func_gui.status_refresh(self)

global main_size
main_size=[1000, 500]
root = maliang.Tk(main_size)
root.center()#居中


global app
app = App(root)


if __name__ == "__main__":
    root.mainloop()
