import os
import sys
import winshell
import window
from tkinter import messagebox
def create_shortcut():
    """创建开机自启动快捷方式"""
    startup_path = os.path.join(
        os.environ['APPDATA'],
        'Microsoft\\Windows\\Start Menu\\Programs\\Startup'
    )
    shortcut_path = os.path.join(startup_path, '防断连脚本.lnk')

    # 获取当前脚本的路径
    script_path = os.path.abspath(__file__)

    # 使用 winshell 创建快捷方式

    with winshell.shortcut(shortcut_path) as sc:
        sc.path = sys.executable
        sc.arguments = f'"{script_path}"'
        sc.working_directory = os.path.dirname(script_path)

def disable_auto_start():
    """单模式启用"""
    try:
        # 删除启动文件夹快捷方式
        startup_path = os.path.join(
            os.environ['APPDATA'],
            'Microsoft\\Windows\\Start Menu\\Programs\\Startup'
        )
        shortcut_path = os.path.join(startup_path, '防断连脚本.lnk')
        if os.path.exists(shortcut_path):
            os.remove(shortcut_path)
    except Exception as e:
        window.messagebox.showerror("错误", f"目标任务取消失败: {str(e)}")
        return False

def check_auto_start():  # 确认自启动状态，
    """检查当前自启动状态"""
    # 检查启动文件夹
    startup_path = os.path.join(
        os.environ['APPDATA'],
        'Microsoft\\Windows\\Start Menu\\Programs\\Startup'
    )
    shortcut_path = os.path.join(startup_path, '防断连脚本.lnk')
    if os.path.exists(shortcut_path):
        return True
    pass

def toggle_auto_start(self):  # 切换自启动
    if self.auto_start_var.get():
        create_shortcut()
        messagebox.showinfo(title="成功", message="已启用开机自启动\nTip:该选项仅为用户级权限\n若被系统阻止,请尝试添加信任")
        return True

    else:
        disable_auto_start()
        messagebox.showinfo(title="成功", message="已禁用开机自启动")
        return True
    #messagebox.showerror("错误", "自启动启用失败")