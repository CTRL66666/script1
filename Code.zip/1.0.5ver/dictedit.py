import tkinter as tk
from tkinter import ttk, messagebox
import random
import json
import network
class DictEditor(tk.Frame):
    """
    通用字典编辑器
    master   : 父容器
    data     : 要编辑的 dict（传进来后原地修改）
    readonly : list，里面写不允许改动的 key
    """
    def __init__(self, app, readonly=None, **kw):
        super().__init__(app.advanced_root, **kw) #让当前实例(self)变成合法的Frame容器,每个 Tkinter 控件 必须 挂靠在一个已存在的“父容器”下
        self.app=app
        self.data = app.params
        self.real_password = 0 #初始化
        self.readonly = set(readonly or [])
        self.before_url=self.app.visit_url
        # 工具栏
        bar = tk.Frame(self)    #给自己再新建一个Frame子框架,挂在self名下
        bar.pack(fill='x')
        ttk.Button(bar, text='➕ 新增参数', command=self.add_item).pack(side='left')
        ttk.Button(bar, text='➖ 删除选中', command=self.del_selected).pack(side='left')
        ttk.Button(bar, text='💾 保存认证信息', command=self.save).pack(side='left')
        ttk.Button(bar, text=' ◀ 重置认证信息', command=self.reset).pack(side='left') #
        ttk.Button(bar, text=' ✍ 帮助', command=self.help_message).pack(side='left')
        #ttk.Button(bar, text=' ✍ 打印认证信息', command=self.print_param).pack(side='left')
        # Treeview 做表格
        self.tree = ttk.Treeview(self, columns=('value',), show='tree headings', selectmode='browse')   #只再建一列（第一列叫 #0),同时显示 树状结构线（tree） 列标题栏（headings）;一次只能选中一行（不能多选）
        self.tree.heading('#0', text='参数') #给内置列 #0起标题 → 将来放“字典的 key”
        self.tree.heading('value', text='值  [修改在后生效]')    #给刚建的自定义列起标题 → 将来放“字典的 value”
        self.tree.column('#0', width=180)   #设置Key 列宽度 180 像素
        self.tree.column('value', width=350)    #设置Value 列宽度 350 像素
        self.tree.pack(fill='both', expand=1, pady=4)   #允许表格同时横向+纵向撑满剩余空间,窗口拉大时，多出来的面积全给表格,上下各留 4 像素边距

        # 双击编辑
        self.tree.bind('<Double-1>', self.on_edit)

        # ====== 1. 把 visit_url 也塞进 Treeview ======
        # 下面 3 行把visit_url“独立变量”当成特殊行插到最前

        self.tree.insert('', 0, iid='__url__',
                         text='校园网认证链接', values=(app.visit_url,))

        self.tree.insert("", 0, iid='__bindingIP__',
                         text='用于绑定动态IP的参数名', values=("",))

        self.refresh_tree()          # 首次填充
        self.editing = None          # 记录当前正在编辑的 cell

    # ---------- 以下为内部方法 ----------
    def refresh_tree(self): #表格清零 → 字典重填
        # 先更新独立变量行
        if self.app.visit_url is not None:  #非空
            self.tree.set('__url__', 'value', self.app.visit_url)
        try:
            if self.app.config["KeyBindingIP"]:  #非空
                self.tree.set('__bindingIP__', 'value', self.app.config["KeyBindingIP"])
        except:pass
        "把当前 dict 内容刷到 Treeview"
        for item in self.tree.get_children():   #当前表格里所有行 ID
            # 1. 只删普通字典行，保留特殊变量行
            if item == '__url__'or'__bindingIP__' :     #
                continue  # 保留独立变量行
            self.tree.delete(item)  #把旧行全部删光，避免重复堆积
        for k, v in self.data.items():  #遍历最新字典的键值对
            if k == 'user_password' :
                display = "***已隐藏***"
                self.real_password = v
            else:
                 display = v  # 掩码
            self.tree.insert('', 'end', text=k, values=(display,))    #在表格末尾插入新行：text=k → 放在第一列（#0）;values=(v,) → 放在第二列（value）

    def on_edit(self, event):
        "双击进入编辑"
        region = self.tree.identify_region(event.x, event.y)
        if region != 'cell':    #'cell' 代表真正双击在数据行上
            return
        col = self.tree.identify_column(event.x)
        if col == '#0':             # 不允许改 key，只改 value
            return
        item = self.tree.identify_row(event.y)  #拿到被点的行 ID（Treeview 每行有个内部字符串编号）
        key = self.tree.item(item, 'text')  #把这行的 Key 文字 取出来(存在 #0 列的 text 字段里）
        if key in self.readonly:
            messagebox.showinfo('提示', f'关键字 “{key}” 只读')
            return

        # 创建一个临时 Entry 盖在 cell 上
        x, y, w, h = self.tree.bbox(item, col)
        self.editing = tk.Entry(self.tree)
        self.editing.place(x=x, y=y, width=w, height=h)
        self.editing.insert(0, self.tree.set(item, col))
        self.editing.focus_set()
        self.editing.bind('<Return>', lambda e: self.finish_edit(item)) #return事件
        self.editing.bind('<FocusOut>', lambda e: self.finish_edit(item))

    def finish_edit(self, item):
        "编辑完成，写回 Treeview"
        new_val = self.editing.get()
        self.tree.set(item, 'value', new_val)   #写回新值
        self.editing.destroy()  #销毁临时Entry输入框
        self.editing = None


    def add_item(self):
        "弹出小窗口，让用户输入新键值"
        dlg = tk.Toplevel(self)
        dlg.title('新增参数')
        # ---- 居中 ----
        self.update_idletasks()  # 强制刷新尺寸
        px = self.winfo_rootx() + (self.winfo_width() - 300) // 2
        py = self.winfo_rooty() + (self.winfo_height() - 120) // 2
        dlg.geometry(f'+{px}+{py}')
        dlg.transient(self)
        dlg.grab_set()
        tk.Label(dlg, text='参数:').grid(row=0, column=0, padx=5, pady=5, sticky='e')
        tk.Label(dlg, text='值:').grid(row=1, column=0, padx=5, pady=5, sticky='e')
        k_var, v_var = tk.StringVar(), tk.StringVar()
        tk.Entry(dlg, textvariable=k_var).grid(row=0, column=1, padx=5, pady=5, sticky='we')
        tk.Entry(dlg, textvariable=v_var).grid(row=1, column=1, padx=5, pady=5, sticky='we')
        #勾选是否绑定ip函数
        '''
        ip_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(dlg, text='自动获取本机 IP',
                        variable=ip_var).grid(row=4, column=0, columnspan=2, pady=5)
        '''
        dlg.columnconfigure(1, weight=1)

        def ok():
            k, v = k_var.get().strip(), v_var.get().strip()
            if not k:
                messagebox.showwarning('警告', 'Key 不能为空')
                return
            if k in self.data:
                messagebox.showwarning('警告', f'Key “{k}” 已存在')
                return
            '''
            # ★ 勾选了立即拿 IP
            if ip_var.get():
                try:
                    v = network.get_current_ip()  # 获取函数
                except Exception as e:
                    messagebox.showerror('获取 IP 失败', str(e))
                    return  # 放弃新增
            '''
            self.data[k] = v
            self.refresh_tree()
            dlg.destroy()

        ttk.Button(dlg, text='确定', command=ok).grid(row=2, column=0, columnspan=2, pady=8)
        dlg.bind('<Escape>', lambda e: dlg.destroy())

    def del_selected(self):
        "删除选中行"
        sel = self.tree.selection()
        if not sel:
            return
        key = self.tree.item(sel[0], 'text')
        '''
        if key in self.readonly:
            messagebox.showinfo('提示', f'关键字 “{key}” 只读，不可删')
            return
        '''
        ans = messagebox.askyesno('确认', f'确定删除参数 “{key}” 吗？\n删除后请保存配置')
        if ans:
            self.data.pop(key, None)
            self.refresh_tree()

    def save(self):
        "把 Treeview 当前内容写回 self.data"
        # 1. 先写回独立变量
        print("before_url:",self.before_url)
        print("now_url:", self.tree.set('__url__', 'value'))
        if self.before_url == self.tree.set('__url__', 'value'): #若确实与默认值不同,则把url赋予新值,否则不更改
            pass
        else:
            print("save():修改了新的url并保存")
            self.app.visit_url=self.tree.set('__url__', 'value')
            self.app.config['visit_url'] = self.app.visit_url  # 保存认证url

        if self.tree.set('__bindingIP__', 'value') !="":
            self.app.config['KeyBindingIP'] = self.tree.set('__bindingIP__', 'value') #
               # '__bindingIP__'

        # 2. 再写回字典
        new_data = {}
        for item in self.tree.get_children():
            if item == '__url__' or item =='__bindingIP__':    #独立变量就跳过   or
                continue
            k = self.tree.item(item, 'text')    #返回text
            v = self.tree.set(item, 'value')
            new_data[k] = v
        self.data.clear()
        self.data.update(new_data)

        self.data["user_password"]=self.real_password
        self.app.save_settings() #全局配置保存
        messagebox.showinfo('提示', '您已保存认证参数配置!\n注意:保存后此工具将只发送当前参数信息给认证网址\n主界面的账号密码及运营商配置可能失效')

    def reset(self):
        from pathlib import Path

        def drop_key_dict(file_path: str | Path,key):
            file_path = Path(file_path)
            with file_path.open(encoding='utf-8') as f:
                data = json.load(f)

            # 1. 直接删掉整个 params 键
            data.pop(key, None)

            # 2. 写回文件
            with file_path.open('w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)

        ans = messagebox.askyesno('确认', f'确定重置 [认证参数] 吗？')
        if ans:
            drop_key_dict(self.app.path,"params")
            drop_key_dict(self.app.path, "visit_url")
            drop_key_dict(self.app.path, "KeyBindingIP")
            messagebox.showinfo('提示', '已重置认证参数配置\n请重启软件后生效!')
        return

    def print_param(self):
        print(json.dumps(self.app.params, ensure_ascii=False, indent=2))
        return


    def help_message(self):
        messagebox.showinfo('帮助', '抓包校园网登录链接以获取自定义参数\n不同学校认证参数可能不同\n目前默认参数仅适应大学[JXUST]\n认证链接更改后,主界面的账号密码将不起作用\n第一行是绑定动态IP的参数名\n将你要绑定的这个参数用来发送当前IP地址\n第三行起填写你的认证信息(即params)\n软件将自动发送你预设好的参数键值对组成的字典\n更改了错误参数可能导致认证失败\n可以尝试重置默认参数')
        return
# ----------------- 以下为演示如何把 DictEditor 嵌到你的登录窗口 -----------------
class DemoGUI:
    def __init__(self):
        self.root = tk.Tk()
        self.advanced_root=tk.Toplevel(self.root)
        self.root.title('DictEditor 演示 —— 登录参数可视化调整')
        self.root.geometry('600x400')
        self.visit_url = "WW"
        # 原始业务数据
        self.params = {
            "callback": "dr1003",
            "login_method": "1",
            "user_account": "13800138000@cmcc",
            "user_password": "123456",
            "wlan_user_ip": "192.160.5.17",
            "wlan_user_ipv6": "",
            "wlan_user_mac": "000000000000",
            "wlan_ac_ip": "10.17.4.1",
            "wlan_ac_name": "",
            "jsVersion": "4.1.3",
            "terminal_type": "1",
            "lang": "zh-cn",
            "v": str(random.randint(1000, 9999)),
            "lang": "zh"
        }

        # 只读字段示例
        readonly_keys = ['callback', 'login_method', 'user_password']

        # 把编辑器放进主窗口
        DictEditor(self,readonly=readonly_keys).pack(fill='both', expand=1, padx=5, pady=5)

        # 模拟“发送登录请求”
        ttk.Button(self.root, text='打印当前 params',
                   command=lambda: print(json.dumps(self.params, ensure_ascii=False, indent=2)))\
            .pack(side='bottom', pady=4)    #json.dumps(self.params, ensure_ascii=False, indent=2)
        #"S_VAR:",self.visit_url
        self.root.mainloop()


if __name__ == '__main__':
    DemoGUI()