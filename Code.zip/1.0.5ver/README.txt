主界面采用了github开源的基于tkinter库的maliang库作为gui层编写,Python环境为3.12及以上,手动修改了部分maliang库代码适配本工具gui界面的逻辑实现,所以即便是安装了maliang库,也需要要先补全部分库代码缺失才能正常运行.也可以通过裁切使用maliang库开发的gui页面代码,改用内置的tkinter界面运行.

缺失代码:maliang库->widgets.py->class IconButton(virtual.Widget)-> 
def config(self, **kwargs) -> None:
        """配置输入框参数，支持动态修改显示字符"""
        if 'show' in kwargs:
            # 更新自身属性
            print(self.texts)
            print("show:", kwargs['show'])
            self.show = kwargs['show']
            # 更新内部SingleLineText的show值
            self.texts[0].show = self.show
            # self.text.config(show=kwargs['show'])
            # texts.SingleLineText(self,show=self.show)
            text = self.get()
            self.set(text)
            # 强制刷新文本显示
            self.texts[0].update()
        if 'command' in kwargs:
            print(self.feature.command)
            self.command = kwargs['command']
            self.feature.command=self.command
            print("config command done")
        if "text" in kwargs:
            self.text = kwargs['text']
            self.texts[0].set(self.text)
            print("config text done")
        if "image" in kwargs:

            self.image_instance.destroy()
            self.image=kwargs['image']
            self.image_instance = images.StillImage(self, ((self.size[1] - self.size[0]) / 2, 0), image=self.image)


    maliang库->widgets.py->class InputBox(virtual.Widget)->
 def cget(self,attr):
        if attr == "show":
            return getattr(self.texts[0],attr,None)

maliang库->widgets.py->class InputBox(virtual.Widget)->
    def config(self, **kwargs) -> None:
        """配置输入框参数，支持动态修改显示字符"""
        if 'show' in kwargs:
            # 更新自身属性
            print(self.texts)
            print("show:",kwargs['show'])
            self.show = kwargs['show']
            # 更新内部SingleLineText的show值
            self.texts[0].show = self.show
            #self.text.config(show=kwargs['show'])
            #texts.SingleLineText(self,show=self.show)
            text=self.get()
            self.set(text)
            # 强制刷新文本显示
            self.texts[0].update()


maliang库->widgets.py->class InputBox(virtual.Widget)->
def __init__()内
附加一行:self.show=show #修改附加
