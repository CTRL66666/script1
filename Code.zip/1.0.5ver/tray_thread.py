import threading
import pystray
import window
import os
from tkinter import messagebox

def minimize_to_tray(self):
    self.root.withdraw()  # 隐藏主窗口
    window.show_disappear_message("程序已最小化到托盘", 3000)
    print("托盘已最小化")

    def restore_window():
        """从托盘恢复窗口"""
        self.root.deiconify()  # 显示主窗口
        if self.tray_icon:
            self.tray_icon.stop()  # 检测存在后,再停止
        self.tray_icon = None
        pass

    def quit_app():  # 内部方法
        self.start_sign = 0  # 启动标记初始化
        # pump_threading.join() #等待pump线程完成
        self.root.destroy()

        if self.tray_icon:
            self.tray_icon.stop()
        os._exit(0)
        pass

    def icon_fresh():  # 托盘消息刷新操作
        if self.tray_icon:

            self.tray_icon.run()

    def create_icon():  # 添加一个菜单项
        self.menu = pystray.Menu(
            pystray.MenuItem('显示窗口', restore_window, default=True),
            pystray.MenuItem('暂停脚本', self.end_script),
            pystray.MenuItem('查看日志', lambda: self.visit_log()),
            pystray.MenuItem('退出程序', quit_app))
        self.tray_icon = pystray.Icon("防断连脚本", self.icon_image,
                                      "防断连程序:\n{0}".format(self.status_label.cget("text")),
                                      menu=self.menu)  #### 创建Icon对象，并设置tooltip

    if self.tray_icon:
        self.tray_icon.stop()
    create_icon()

    # 在独立线程运行托盘图标
    self.tray_thread = threading.Thread(target=icon_fresh, daemon=True)
    self.tray_thread.start()

#状态切换函数
def pystray_switch(self):
    if self.pystray_sign == 0:
        self.pystray_sign = 1
        self.config["pystray_sign"] = 1
        self.root.protocol('WM_DELETE_WINDOW', lambda:minimize_to_tray(self))  # 重写关闭按钮行为
        self.pystray_btn.config(text="后台禁用")
        result=messagebox.askquestion(title="成功", message="启用了后台托盘最小化\n是否保存配置")
    else:
        self.pystray_sign = 0
        self.config["pystray_sign"] = 0
        self.root.protocol('WM_DELETE_WINDOW', self.root.destroy)  # 重写关闭按钮行为
        self.pystray_btn.config(text="后台运行")
        result=messagebox.askquestion(title="成功", message="关闭了后台托盘最小化\n是否保存配置")

    if result=="yes":
        self.save_settings()
    else:
        pass