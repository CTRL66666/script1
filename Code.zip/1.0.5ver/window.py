import tkinter as tk
import sys
import time

#from main import app

def check_window_exists(window):
    return window is not None and tk.Toplevel.winfo_exists(window)  # 判断窗口是否存在

def toggle_relief(button):  # 按钮按下显色
    current_relief = button.cget("relief")
    if current_relief == tk.RAISED:
        button.config(relief=tk.SUNKEN, bg="white")
    else:
        button.config(relief=tk.RAISED, bg="green")


def show_disappear_message(message, duration=3000, window_width=200, window_height=60):
    from gui import app
    """
    显示一个自动消失的消息框
    :param title: 消息框标题
    :param message: 消息框内容
    :param duration: 消息框显示时间（毫秒），默认3000毫秒（3秒）
    """
    # 创建一个Tkinter根窗口
    root2 = tk.Toplevel()
    root2.overrideredirect(True)  # 去掉窗口边框和标题栏
    root2.attributes('-topmost', True)  # 置顶窗口

    # 设置窗口位置为屏幕右下角
    screen_width = app.screen_width
    screen_height = app.screen_height
    window_width = 200
    window_height = 60
    root2.geometry(
        f"{window_width}x{window_height}+{screen_width - window_width - 10}+{screen_height - window_height - 60}")

    # 创建消息框内容
    label = tk.Label(root2, text=message, font=('Arial', 9), padx=20, pady=20)
    label.pack(fill=tk.BOTH, expand=True)

    # 设置窗口在指定时间后自动销毁
    def destroy_window():
        root2.destroy() ######

    root2.after(duration, destroy_window)

def show_disappear_message2(message,
                           duration=3000,
                           window_width=200,
                           window_height=60,
                           color="#F0F0F0",
                           main_window=None):
    """
    优化后的自动消失消息框
    :param message: 显示的消息内容
    :param duration: 显示时长（毫秒）
    :param window_width: 窗口宽度
    :param window_height: 窗口高度
    :param color: 背景颜色
    :param main_window: 主窗口引用（可选）
    """
    # 创建子窗口
    root2 = tk.Toplevel()
    root2.wm_overrideredirect(True)
    root2.attributes('-topmost', True)
    root2.configure(bg=color)

    # 获取屏幕尺寸
    if main_window:
        screen_width = main_window.winfo_screenwidth()
        screen_height = main_window.winfo_screenheight()
    else:
        screen_width = root2.winfo_screenwidth()
        screen_height = root2.winfo_screenheight()

    # 计算窗口位置
    pos_x = screen_width - window_width - 10
    pos_y = screen_height - window_height - 60

    # 设置窗口位置和大小
    root2.geometry(f"{window_width}x{window_height}+{pos_x}+{pos_y}")

    # 创建内容标签
    label = tk.Label(root2,
                     text=message,
                     font=('Arial', 9),
                     bg=color,
                     padx=15,
                     pady=10,
                     wraplength=180)
    label.pack(expand=True, fill='both')

    # 自动销毁逻辑
    def destroy_window():
        for i in range(10, -1, -1):
            root2.attributes('-alpha', i / 10)
            root2.update()
            time.sleep(0.02)
        root2.destroy()

    root2.after(duration, destroy_window)
    root2.attributes('-alpha', 0)  # 初始透明

    # 淡入动画
    for i in range(0, 11):
        root2.attributes('-alpha', i / 10)
        root2.update()
        time.sleep(0.02)


'''debug窗口'''


def toggle_debug_window(self):

    if self.debug_window is None or not self.debug_window.winfo_exists():
        create_debug_window(self)
    else:
        self.debug_window.destroy()
        self.debug_window = None


def create_debug_window(self):
    self.debug_window = tk.Toplevel(self.root)
    self.debug_window.title("调试窗口")
    self.debug_window.geometry("600x400")

    # 创建带滚动条的文本框
    self.debug_text = tk.Text(self.debug_window)
    scrollbar = tk.Scrollbar(self.debug_window)
    scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
    self.debug_text.pack(fill=tk.BOTH, expand=True)

    # 配置滚动条
    self.debug_text.config(yscrollcommand=scrollbar.set)
    scrollbar.config(command=self.debug_text.yview)

    # 重定向标准输出
    class StdoutRedirector:
        def __init__(self, text_widget):
            self.text_widget = text_widget

        def write(self, message):
            if not self.text_widget.winfo_exists():
                sys.__stdout__.write(message)
                return

            try:
                self.text_widget.after(0, self._update_text, message)
            except Exception as e:
                sys.__stdout__.write(f"重定向失败: {str(e)}\n")

        def _update_text(self, message):
            self.text_widget.insert(tk.END, message)
            self.text_widget.see(tk.END)

        def flush(self):
            pass

    sys.stdout = StdoutRedirector(self.debug_text)
    # 窗口关闭事件处理
    self.debug_window.protocol("WM_DELETE_WINDOW", lambda:on_debug_close(self))


def on_debug_close(self):
    """恢复标准输出并销毁窗口"""
    sys.stdout = sys.__stdout__
    self.debug_window.destroy()
    self.debug_window = None


def debug_print(self, *args, **kwargs):
    # 将 print 内容显示在调试窗口中
    message = " ".join(map(str, args))
    self.debug_text.insert(tk.END, time.strftime("%Y-%m-%d %H:%M:%S") + " :  " + message + "\n")  # 貌似插入时间显示没用
    self.debug_text.see(tk.END)

    # 同时保持控制台输出
    self.original_print(message)


if __name__ == "__main__":
    show_disappear_message("启动中", "启动中", duration=3000)
    show_disappear_message("成功", "成功连接!", duration=3000)
    print("启动成功")