from gui import app
app
#list.append(app.)