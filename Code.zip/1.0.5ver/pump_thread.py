import win32gui
import win32con
import threading
from threading import Thread
import time
import window
from gui import app
def register_wake_notify():

    # 创建隐藏消息窗口
    wc = win32gui.WNDCLASS()
    wc.lpfnWndProc = _power_event_handler  # 正确绑定消息处理函数
    wc.lpszClassName = "PowerMonitorClass"
    class_atom = win32gui.RegisterClass(wc)

    try:
        class_atom = win32gui.RegisterClass(wc)
    except win32gui.error as e:
        if e.winerror != 1410:  # 忽略类已存在的错误
            raise

    # 创建窗口实例
    app.hwnd = win32gui.CreateWindowEx(
        0,  # dwExStyle
        wc.lpszClassName,  # lpClassName
        "PowerMonitor",
        0,  # dwStyle
        0, 0, 0, 0,  # x, y, nWidth, nHeight
        None,
        None,
        wc.hInstance,
        None
    )

    # 启动独立消息线程

    app.pump_threading = threading.Thread(target=_message_pump, daemon=True)
    app.pump_threading.start()


def _message_pump():
    """独立消息循环线程"""
    while app.start_sign == 1:
        try:
            win32gui.PumpMessages()  # 正确调用方式（无参数）
        except Exception as e:
            print(f"消息循环异常: {str(e)}")
            time.sleep(1)


def _power_event_handler(hwnd, msg, wparam, lparam):
    """消息处理回调"""
    if msg == win32con.WM_POWERBROADCAST:
        if wparam == win32con.PBT_APMRESUMEAUTOMATIC:
            print("检测到系统唤醒")
            app.login()  # 激活一次登录
            if app.start_sign and (not app.script_thread.is_alive()) : #休眠后老线程可能被系统暂停，但仍然is_alive()存活
                print("重启守护线程")
                app.script_thread = Thread(target=app.cycle_login, daemon=True) #这里是创建了一个新线程代替老线程工作
                app.script_thread.start()
                app.status_label.config(text="已恢复运行")
                window.show_disappear_message("提示", "防断连恢复工作", 10000)
    return 0  # 必须返回0