import tkinter as tk
from tkinter import messagebox
import os
import sys

def status_refresh(app):
    if not app.start_sign and app.script_thread is None :
        #这里添加新老版gui判断
        app.status_label = tk.Label(app.root,
                                     text="状态: 就绪 配置装填:" + str(app.is_loaded))  ###self.is_loaded.cget("text")

        if app.open_to_use: app.status_label.config(text=f"状态: 就绪 正在执行自动运行指令")
        app.status_label.grid(row=3, columnspan=5)

    elif not app.start_sign and app.script_thread is not None :
        app.status_label.config(text=f"已停止,共执行{app.login_count}次")
        app.root.title(f"已停止")
        if app.tray_icon:
            app.tray_icon.title = "防断连程序\n{0}".format(app.status_label.cget("text"))

    else:
        if app.open_to_use and app.pystray_sign and not app.has_worked:
            app.status_label.config(text="正在自动运行脚本...")

        if app.start_sign and not app.wlan_finished:
            app.status_label.config(text=f"正在执行wifi规则...")

        elif app.start_sign and app.wlan_finished and app.login_result:
            app.root.title(f"运行中 - 已登录{app.login_count}次")
            app.status_label.config(text=f"运行中 - 已登录{app.login_count}次")
            if app.tray_icon:
                app.tray_icon.title = "防断连程序\n{0}".format(app.status_label.cget("text"))  # 尝试实时更新

        elif app.start_sign and app.wlan_finished :
            app.status_label.config(text=f"wifi规则执行完毕...")

        if app.login_result == False :
            app.status_label.config(text=f"登录失败，请重试")

        if app.timer >= app.loop_time and app.start_sign:
            app.root.title(f"运行中 - 已登录{app.login_count}次")
            app.status_label.config(text=f"运行中 - 已登录{app.login_count}次")
            if app.tray_icon:  # 托盘信息更新
                app.tray_icon.title = "防断连程序\n{0}".format(app.status_label.cget("text"))
        elif app.login_count >= app.max_login:
            messagebox.showinfo(title=app.config['channel'] + "登录停止", message="已达最大登录次数上限")
            app.root.title(f"已停止")
            app.status_label.config(text=f"已停止 达到最大登录次数 - 已登录{app.login_count}次")
            app.start_sign = 0

def gui_switch(app):
    if app.gui_ver =="new":
        app.config["gui_ver"]="old"
        app.gui_ver = "old"
        messagebox.showinfo("切换成功", "已将可视化界面退回旧版\n将在下次启动时生效")
        app.save_settings()

    elif app.gui_ver =="old":
        app.config["gui_ver"] = "new"
        app.gui_ver = "new"
        messagebox.showinfo("切换成功", "已将可视化界面选择新版\n将在下次启动时生效")
        app.save_settings()

def data_reset(app):
    result = messagebox.askquestion(title="恢复默认？", message="请确认是否清除所有数据？\n将在下次启动时生效")
    if result=="yes":
        try:
            os.remove(app.path)
            print(f"文件 {app.path} 已成功删除")
            messagebox.showinfo("成功","成功清除配置文件\n将在下次启动时生效")
        except FileNotFoundError:
            print(f"文件 {app.path} 不存在")
            messagebox.showerror("失败","目标路径不存在！")
        except PermissionError:
            print(f"没有权限删除文件 {app.path}")
            messagebox.showerror("失败", "该路径被锁定！")
        except Exception as e:
            print(f"删除文件时错误发生：{e}")
            messagebox.showerror("错误",message=str(e))

def resource_path(relative_path):
    """ 自动适配打包环境与开发环境的路径 """
    if hasattr(sys, '_MEIPASS'):
        base_path = sys._MEIPASS  # 打包后资源路径
    else:
        base_path = os.path.abspath(".")  # 开发环境路径
    return os.path.join(base_path, relative_path)