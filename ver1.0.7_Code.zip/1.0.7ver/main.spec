# -*- mode: python ; coding: utf-8 -*-


a = Analysis(
    ['main.py'],
    pathex=[],
    binaries=[],
    datas=[('eyes_icon.png', '.'),
        ('eyes_closed_icon.png', '.'),
        ('image.ico', '.'),
	('school.jpg', '.'),
        ('user_icon.png', '.'),
        ('password_icon.png', '.'),
	('start_icon.png', '.'),
	('stop_icon.png', '.'),
	('wifi_icon.png', '.'),
	('question_icon.png', '.')],
    hiddenimports=['queue', 'tkinter', 'PIL', 'requests', 'json', 'os', 'io', 'base64', 'PIL.Image', 'PIL.ImageTk'],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='main',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=['image.ico'],
)
